package edu.ktu.glang.interpreter;

public class FunctionDeclaration {
}
