# P175B124 Programavimo kalbų teorija [KTU]
### Apie repozitoriją
Čia kaupiami 2023 PKT modulio studentų projektiniai darbai.
Komandos pavadinimas - "Draugai Trys".

## Komandos nariai
Erikas Briauka - IFF-1/8
Aleksas Juzukonis - IFF-1/8
Matas Palujanskas - IFF-1/8

# FL# - friends language sharp.

# Įrankiai
[Apache Maven 3.9.2]
[IntelliJ IDEA Community Edition 2023.1.1]
[Bitbucket]
[ANTLR v4 plugin]
# Paleidimas
Build
Generate ANTLR visitor with:

mvn clean antlr4:antlr4@generate-visitor
Build jar with:

mvn clean install
Run jar with:

java -jar target/glang-interpreter-1.0.jar -f samples/test
java -jar target/glang-interpreter-1.0.jar -i



@[KTU] 2023
