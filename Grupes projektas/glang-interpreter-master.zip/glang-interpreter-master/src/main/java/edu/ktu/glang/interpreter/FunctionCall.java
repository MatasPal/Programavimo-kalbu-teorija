package edu.ktu.glang.interpreter;

public class FunctionCall {
}
