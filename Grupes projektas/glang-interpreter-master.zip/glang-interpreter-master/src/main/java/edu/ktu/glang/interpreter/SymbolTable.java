package edu.ktu.glang.interpreter;

import java.util.*;

public class SymbolTable {
    private final Map<String, Object> table;
    private final Map<String, String> typeTable;

    private Stack<ArrayList<String>> scope;

    private Map<String, Map<String, String>> functable;



    public SymbolTable() {
        table = new HashMap<>();
        typeTable = new HashMap<>();
        scope = new Stack<ArrayList<String>>();
        scope.push(new ArrayList<String>());
        functable = new HashMap<String, Map<String, String>>();
    }

    public void put(String name, Object value) {
        table.put(name, value);
    }

    public void put(String name, Object value, String type) {
        table.put(name, value);
        typeTable.put(name, type);
        scope.peek().add(name);
    }

    public void putFunc(String name, String paramname, String paramtype){
        if (functable.containsKey(name)){
            functable.get(name).put(paramname, paramtype);
        }
        else {
            Map<String, String> map = new HashMap<String, String>();
            map.put(paramname, paramtype);
            functable.put(name, map);
        }
    }

    public String GetFuncParamType(String name, String paramname){
        return functable.get(name).get(paramname);
    }

    public Object get(String name) {
        return table.get(name);
    }

    public String getType(String name) {
        return typeTable.get(name);
    }

    public void remove(String id){
        table.remove(id);
        typeTable.remove(id);
    }

    public void initializeScope(){
        scope.push(new ArrayList<String>());
    }


    public boolean contains(String name) {
        return table.containsKey(name);
    }

    public void clearScope(){
        for (String val : scope.peek()){
            remove(val);
        }
        scope.pop();
    }
}