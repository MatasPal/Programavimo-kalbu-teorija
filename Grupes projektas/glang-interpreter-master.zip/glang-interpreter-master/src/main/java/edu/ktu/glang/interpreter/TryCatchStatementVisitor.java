package edu.ktu.glang.interpreter;

import gen.GLangBaseVisitor;
import gen.GLangParser;

import java.io.FileWriter;

public class TryCatchStatementVisitor extends GLangBaseVisitor<Object> {

    private final InterpreterVisitor parent;

    private StringBuilder fileWriter;

    public TryCatchStatementVisitor(InterpreterVisitor parent) {
        this.parent = parent;
        fileWriter = new StringBuilder();
    }

    public void PutWriter(StringBuilder writer){
        fileWriter = writer;
    }

    @Override
    public Object visitTryCatchStatement(GLangParser.TryCatchStatementContext ctx) {
        String exception = null;
        try {
            for (GLangParser.StatementContext statement : ctx.statement()) {
                //System.out.println("AA");
                parent.visit(statement);
            }
        }
        catch (Exception e){
            exception = e.toString();
            if (exception != null)
                fileWriter.append(exception).append("\n");
            for (GLangParser.StatementContext statement : ctx.catchClause().statement()) {
                //System.out.println("AA");
                parent.visit(statement);
            }
        }
        return null;





    }

}